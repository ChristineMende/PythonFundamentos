Create database escola;

USE escola;

create table ALUNO(
	cpf varchar(11) PRIMARY KEY,
    nome_aluno varchar(50),
	endereco_aluno varchar(50), 
    telefone varchar(25),
    data_nasc date
);

create table DEPARTAMENTO(
	codigo_dpto int PRIMARY KEY auto_increment,
	nome_dpto varchar(20)
);

create table CURSO(
	codigo_curso int PRIMARY KEY auto_increment,
	nome_curso varchar(25),
    descricao text(200),
    codigo_dpto int,
    constraint fk_cursoDept foreign key (codigo_dpto) references DEPARTAMENTO(codigo_dpto)
);

create table PROFESSOR(
	matricula_prof int(10) PRIMARY KEY auto_increment,
	nome_prof varchar(50),
    endereco varchar(100), 
    telefone varchar(25),
    data_nasc date,
    codigo_dpto int,
    data_contrat date,
    constraint fk_profDept foreign key (codigo_dpto) references DEPARTAMENTO(codigo_dpto)
);

create table MATRICULA(
    id_curso int,
	cpf_aluno varchar(11),
    data_matr date,
    primary key (id_curso,cpf_aluno),
    constraint fk_matCurso foreign key (id_curso) references CURSO(codigo_curso),
    constraint fk_matAluno foreign key (cpf_aluno) references ALUNO(cpf)
);

create table DISCIPLINA(
	codigo_disc int primary key auto_increment,
    nome varchar(50),
    qtd_credito tinyint,
    matricula_prof int,
    constraint fk_discProf foreign key (matricula_prof) references PROFESSOR(matricula_prof)
);

create table CURSA(
	cpf_aluno varchar(11),
    id_disc int,
    primary key (cpf_aluno,id_disc),
    constraint fk_cursaAluno foreign key (cpf_aluno) references ALUNO(cpf),
	constraint fk_cursaDisc foreign key (id_disc) references DISCIPLINA(codigo_disc)
);    


create table PRE_REQ(
	codigo_disc int,
    codigo_disc_dependencia int,
    primary key (codigo_disc,codigo_disc_dependencia),
    constraint fk_preReqDic foreign key (codigo_disc) references DISCIPLINA(codigo_disc),
    constraint fk_preReqDependenc foreign key (codigo_disc_dependencia) references DISCIPLINA(codigo_disc)
);

create table COMPOE(
	codigo_curso int,
    codigo_disc int,
    primary key (codigo_curso,codigo_disc),
    constraint fk_compoeCurso foreign key (codigo_curso) references CURSO(codigo_curso),
    constraint fk_compoeDisc foreign key (codigo_disc) references DISCIPLINA(codigo_disc)
);
