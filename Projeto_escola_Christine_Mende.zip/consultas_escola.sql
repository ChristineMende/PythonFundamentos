-- Query 1: Produza um relatório que contenha os dados dos alunos matriculados em todos os cursos oferecidos pela escola.

select
	A.*,
    B.id_curso,
    C.nome_curso
from aluno as A

left join 
	matricula as B
on 
	A.cpf = B.cpf_aluno

left join
	curso as C
on 
	B.id_curso = C.codigo_curso;
    
    
-- Query 2: Produza um relatório com os dados de todos os cursos, com suas respectivas disciplinas, oferecidos pela escola 
select
	A.codigo_curso,
    A.nome_curso,
    A.descricao,
    B.codigo_disc,
    C.nome as nome_disciplina
from curso as A

left join 
	compoe as B
on 
	A.codigo_curso = B.codigo_curso

left join
	disciplina as C
on 
	B.codigo_disc = C.codigo_disc;
    

-- Query 3: Produza um relatório que contenha o nome dos alunos e as disciplinas em que estão matriculados  

select
	A.cpf as cpf_aluno,
    A.nome_aluno,
    B.id_disc,
    C.nome as nome_disciplina
from aluno as A

left join 
	cursa as B
on 
	A.cpf = B.cpf_aluno

left join
	disciplina as C
on 
	B.id_disc = C.codigo_disc;
    
-- Query 4: Produza um relatório com os dados dos professores e as disciplinas que ministram
select
	A.*,
    B.codigo_disc,
    B.nome as nome_disciplina
from professor as A

left join 
	disciplina as B
on 
	A.matricula_prof = B.matricula_prof;

-- Query 5: Produza um relatório com os nomes das disciplinas e seus pré-requisitos
select
	A.codigo_disc,
    A.nome as nome_disciplina,
    B.codigo_disc_dependencia,
    C.nome as nome_disciplina_dependencia
from disciplina as A

left join 
	pre_req as B
on 
	A.codigo_disc = B.codigo_disc
    
left join 
	disciplina as C
on 
	B.codigo_disc_dependencia = C.codigo_disc;
        
-- Query 6: Produza um relatório com a média de idade dos alunos matriculados em cada curso
select
	C.codigo_curso,
    C.nome_curso, 
    sum(TIMESTAMPDIFF (year, data_nasc, curdate()))/count(cpf) as idade_media_por_curso
from aluno as A

right join 
	matricula as B
on 
	A.cpf = B.cpf_aluno

right join
	curso as C
on 
	B.id_curso = C.codigo_curso
group by C.nome_curso;
    
-- Query 7: Produza um relatório com os cursos oferecidos por cada departamento
select
	A.codigo_dpto,
    A.nome_dpto,
    B.codigo_curso,
    B.nome_curso
from departamento as A

left join 
	curso as B
on 
	A.codigo_dpto = B.codigo_dpto;
